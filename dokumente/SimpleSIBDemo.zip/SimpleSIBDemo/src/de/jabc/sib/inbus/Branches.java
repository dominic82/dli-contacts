package de.jabc.sib.inbus;

/**
 * This interface defines the branch labels used by SIBs.
 * 
 * @author Markus Doedt
 */
public interface Branches {

	public static final String TRUE = "true";

	public static final String FALSE = "false";

	public static final String DEFAULT = "default";

	public static final String NEXT = "next";

	public static final String EXIT = "exit";

	public static final String GREATER = "greater";

	public static final String LESS = "less";

	public static final String EQUAL = "equal";
	
	public static final String NOT_EQUAL = "notEqual";
	
	public static final String OTHER = "other";

	public static final String ERROR = "error";
	
	public static final String EMPTY_STRING = "emptyString";

}

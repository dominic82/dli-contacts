package de.jabc.sib.inbus;

import org.apache.log4j.Logger;

import de.metaframe.jabc.framework.execution.ExecutionEnvironment;
import de.metaframe.jabc.framework.execution.context.ExecutionContext;
import de.metaframe.jabc.framework.sib.DocType;
import de.metaframe.jabc.framework.sib.SIB;
import de.metaframe.jabc.framework.sib.SIBMetaInfo;
import de.metaframe.jabc.framework.sib.SIBUtilities;
import de.metaframe.jabc.framework.sib.annotation.SIBClassLoader;
import de.metaframe.jabc.framework.sib.util.Documentation;
import de.metaframe.jabc.framework.sib.util.IconCache;
import de.metaframe.jabc.framework.sibgraph.model.SIBGraphModel;
import de.metaframe.jabc.sib.Executable;
import de.metaframe.jabc.sib.LocalCheck;

/**
 * This class provides a skeleton implementation for the SIBs in this library.
 * 
 * @author Markus Doedt
 */
@SIBClassLoader
public abstract class AbstractSIB implements SIBMetaInfo, LocalCheck, Executable {

	/**
	 * This class lazily loads the logger. The SIB classes themselves should
	 * usually have nothing to log (unlike their service adapters) so the memory
	 * consumption of the SIB loggers can be minimized.
	 */
	protected static class Log {

		/**
		 * The logger instance of this SIB library.
		 */
		public static final Logger INSTANCE = Logger.getLogger(AbstractSIB.class);

	}

	/**
	 * This class holds the icon cache instance. Keeping this instance in a
	 * separate class allows for thread-safe lazy initialization of the cache.
	 * Remember, we do not need icons when running in headless mode.
	 */
	protected static class Icons {

		/**
		 * The icon cache used to load icons for this SIB library.
		 */
		public static final IconCache INSTANCE = new IconCache(AbstractSIB.class);

	}

	/**
	 * This class holds the documentation instance. Keeping this instance in a
	 * separate class allows for thread-safe lazy initialization of the
	 * documentation. Remember, we do not need resource bundles when running in
	 * headless mode.
	 */
	protected static class Strings {

		/**
		 * The bundle used to load documentation strings for this SIB library.
		 */
		public static final Documentation INSTANCE = new Documentation(AbstractSIB.class);

	}

	/**
	 * @see de.metaframe.jabc.framework.sib.SIBMetaInfo#getDocumentation(DocType,
	 *      String)
	 */
	public String getDocumentation(DocType type, String param) {
		return Strings.INSTANCE.get(this, type, param);
	}

	/**
	 * @see de.metaframe.jabc.sib.Executable#trace(ExecutionEnvironment)
	 */
	public abstract String trace(ExecutionEnvironment environment);

	/**
	 * @see de.metaframe.jabc.sib.LocalCheck#type()
	 */
	public Object type() {
		return null;
	}

	/**
	 * @see de.metaframe.jabc.sib.LocalCheck#checkSIB(SIB)
	 */
	public void checkSIB(SIB sib) {
		SIBUtilities.execute(StandardCheck.MISSING_SOURCES.getKey(), sib);
		SIBUtilities.execute(StandardCheck.MISSING_TARGETS.getKey(), sib);
		SIBUtilities.execute(StandardCheck.MISSING_BRANCH_LABELS_CUSTOM_LVL.getKey(), sib, LCStatus.ERROR);
		SIBUtilities.execute(StandardCheck.UNASSIGNED_BRANCHES_ERROR_CUSTOM_LVL.getKey(), sib,
				new String[] { Branches.ERROR }, LCStatus.WARN, LCStatus.INFO);
	}


	/**
	 * Checks whether the specified SIB parameter has been exported as a model
	 * parameter. Usually, model parameters should not be local-checked because
	 * their effective values are provided by a graph SIB.
	 * 
	 * @param sib
	 *            The SIB whose parameter is to check.
	 * @param field
	 *            The name of the SIB parameter to check.
	 * @return {@code true} if the specified SIB parameter is a model parameter,
	 *         {@code false} otherwise.
	 * @throws NullPointerException
	 *             If any method parameter is {@code null}
	 */
	protected boolean isModelParameter(SIB sib, String field) {
		SIBGraphModel model = sib.getCell().getModel();
		return model.getModelArguments().findParameter(field, sib) != null;
	}
	
	/**
	 * Logs the specified error.
	 * 
	 * @param environment
	 *            The current execution environment, must not be {@code null}.
	 * @param message
	 *            The message to log, may be {@code null}.
	 * @param cause
	 *            The cause of the error, may be {@code null}.
	 */
	protected static void logError(ExecutionEnvironment environment, String message, Throwable cause) {
		if (Log.INSTANCE.isDebugEnabled()) {
			Log.INSTANCE.error(message, cause);
			StringBuilder str = new StringBuilder(1024);
			str.append("Dumping stack of execution contexts:");
			ExecutionContext ctx = environment.getLocalContext();
			for (int i = 0; ctx != null; ctx = ctx.getParent(), i++) {
				str.append("\n\tDepth " + i);
				for (String key : ctx.keySet()) {
					str.append("\n\t\t").append(key);
					str.append(" = ").append(ctx.getLocal(key));
				}
			}
			Log.INSTANCE.error(str);
		} else {
			Log.INSTANCE.error(message + ": " + cause + " (enable debug level logging for more details)");
		}
		ExecutionContext context = environment.getLocalContext();
		if (context != null) {
			context.putGlobally("exception", cause);
		}
	}

}

package de.jabc.sib.inbus;

import de.metaframe.jabc.framework.execution.ExecutionEnvironment;
import de.metaframe.jabc.framework.sib.SIB;
import de.metaframe.jabc.framework.sib.SIBUtilities;
import de.metaframe.jabc.framework.sib.annotation.SIBClass;
import de.metaframe.jabc.framework.sib.annotation.SIBStatus;
import de.metaframe.jabc.framework.sib.parameter.ContextKey;

/**
 * A simple SIB.
 * 
 * @author Markus Doedt
 * 
 */
@SIBClass("dli/ExampleSIB")
@SIBStatus("IMPLEMENTED")
public class ExampleSIB extends AbstractSIB {

	/**
	 * The final branches of this SIB.
	 */
	public static final String[] BRANCHES = { Branches.TRUE, Branches.FALSE, Branches.EMPTY_STRING, Branches.ERROR };

	/**
	 * The key and scope of the variable to check.
	 */
	public ContextKey variable = new ContextKey("variable", ContextKey.Scope.DECLARED, true);

	/**
	 * @see de.metaframe.jabc.framework.sib.SIBMetaInfo#getIcon()
	 */
	public Object getIcon() {
		return Icons.INSTANCE.get("dice");
	}

	/**
	 * @see de.metaframe.jabc.sib.CodeGeneratorBlock#execute(ExecutionEnvironment)
	 */
	public String trace(ExecutionEnvironment env) {
		try {
			Object value = env.get(variable);

			if ("".equals(value)) {
				return Branches.EMPTY_STRING;
			}

			return (value != null) ? Branches.TRUE : Branches.FALSE;
		} catch (Exception e) {
			logError(env, "Failed to check variable", e);
			return Branches.ERROR;
		}
	}

	/**
	 * @see de.metaframe.jabc.sib.LocalCheck#checkSIB(SIB)
	 */
	@Override
	public void checkSIB(SIB sib) {
		super.checkSIB(sib);
		if (!isModelParameter(sib, "variable")) {
			if (this.variable.getKey().length() <= 0) {
				SIBUtilities.addError(sib, Strings.INSTANCE.getNonNull(sib, "check.variable"));
			}
		}
	}

}
